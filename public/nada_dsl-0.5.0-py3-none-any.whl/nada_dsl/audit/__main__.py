"""Execute the command line interface entry point."""
from nada_dsl.audit import _main
_main()
