"""
Custom exceptions used in this package.
"""
class NadaNotAllowedException(Exception):
    pass
